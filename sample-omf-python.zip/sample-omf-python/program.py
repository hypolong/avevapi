import json
from fastapi import Request
import requests

# Step 1: get needed variables 
appsettings = {}
with open('appsettings.json', 'r') as f:
    appsettings = json.load(f)

resource = appsettings.get('Resource')
api_version = appsettings.get('ApiVersion')
tenant_id = appsettings.get('TenantId')
client_id = appsettings.get('ClientId')
client_secret = appsettings.get('ClientSecret')
namespace_id = appsettings.get('NamespaceId')

# Step 2: get the authentication endpoint from the discovery URL
wellknown_information = requests.get(f'{resource}/identity/.well-known/openid-configuration')
token_url = json.loads(wellknown_information.content)["token_endpoint"]

# Step 3: use the client ID and Secret to get the needed bearer token
token_information = requests.post(token_url,data={'client_id': client_id,'client_secret': client_secret,'grant_type': 'client_credentials'})


token = json.loads(token_information.content)["access_token"]
# # write the token to a txt file
# with open("tenant_token.txt", "w", encoding="utf-8") as f:
#     f.write(token)

# Step 4: test token by calling the base tenant endpoint 
msg_headers= {"Authorization": f'Bearer {token}'}
test = requests.get(f'{resource}/api/{api_version}/Tenants/{tenant_id}', headers=msg_headers)

# write the confirmation query result to a txt file
with open("tenant_response.txt", "w", encoding="utf-8") as f:
    f.write(test.text)

url = (
    f'{resource}/api/{api_version}/Tenants/{tenant_id}/'
    f"Namespaces/{namespace_id}/Streams?query=*opcua1.1*&count=1000"
)

r = requests.get(url, headers=msg_headers)

streams = r.json()

if len(streams) > 0:
    # write the queried streams to a JSON file to check the stream information
    with open("streams.json", "w", encoding="utf-8") as f:
        json.dump(streams, f, indent=4, ensure_ascii=False)

    print("=============get all streams within '%'====================================")
    print(f"Saved {len(streams)} streams to streams.json")

    # deal Streams
    # ****************** this is for deleting non-normal streams by OMF ******************
    print("===================stream deal====================================")
    msg_headers= {"MessageType": "container", "MessageFormat": "json","OmfVersion": "1.0", "Action": "delete", "Authorization": f'Bearer {token}'}

    del_bode=[]
    for s in streams:
        del_bode.append({
            "id": s["Id"], "typeid": s["TypeId"]
        })

    delete_url = (
            f'{resource}/api/{api_version}/Tenants/{tenant_id}/'
            f"Namespaces/{namespace_id}/omf"
        )
    r_delete = requests.post(delete_url, headers=msg_headers, json=del_bode)
    print(r_delete.json())
    print(r_delete.status_code)

    # ****************** this is for deleting normal streams one by one, but it is not used in the final code ******************
    # for s in streams:
    #     stream_id = s["Id"]
    #     stream_id = (
    #         stream_id
    #         .replace("%5b", "%5B")
    #         .replace("%5d", "%5D")
    #     )
    #     stream_id = stream_id.replace("%", "%25")
        
    #     print("stream_id:", stream_id)

    #     delete_url = (
    #         f'{resource}/api/{api_version}/Tenants/{tenant_id}/'
    #         f"Namespaces/{namespace_id}/Streams/{stream_id}"
    #     )
        
    #     from requests import Request
    #     req = Request(
    #         "GET",
    #         delete_url,
    #         headers=msg_headers
    #     ).prepare()
    #     print("=============URL====================================")
    #     print(req.url)

    #     print("=============get test====================================")
    #     r_get = requests.get(req.url, headers=msg_headers)
    #     print("returned get json:", r_get.json())
    #     print("returned get status:", r_get.status_code)

    #     print("=============delete test====================================")
    #     r_delete = requests.delete(delete_url, headers=msg_headers)
    #     print("returned deletejson:",r_delete.json())
    #     print("returned delete status:",r_delete.status_code)
    #     if r_delete.status_code == 204:
    #         print("Stream deleted successfully.")
    #     else:
    #         print("Failed to delete stream.")
    #         break  # Stop the loop if deletion fails
else:
    print("No streams found.")